import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-creatasks',
  templateUrl: './creatasks.component.html',
  styleUrls: ['./../index/app.component.css']
})
export class CreatasksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
